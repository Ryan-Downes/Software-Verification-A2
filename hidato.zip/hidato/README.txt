> Supports Python 2.7

> Make the shell script runnable: $ chmod u+x hidato

> Runs in CDF Bash Shell


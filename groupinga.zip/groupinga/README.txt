> Supports Python 2.7

> Make the shell script runnable: $ chmod u+x groupinga

> Runs in CDF Bash Shell
